## Module <accounting_pdf_reports>

#### 01.02.2022
#### Version 12.0.2.3.0
##### ADD
- Translation de 
