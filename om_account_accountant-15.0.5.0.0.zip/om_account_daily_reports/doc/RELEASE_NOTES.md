## Module <om_account_daily_reports>

#### 03.03.2022
#### Version 15.0.2.0.0
##### IMP
- code refactoring
